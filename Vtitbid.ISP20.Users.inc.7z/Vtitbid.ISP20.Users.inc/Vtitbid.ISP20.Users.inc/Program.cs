﻿namespace Vtitbid.ISP20.Users.inc
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Zodiac kirill = new Zodiac();
            Console.WriteLine(Zodiac.GetZodiacsArray()); 
            
            System.Console.WriteLine(kirill);
            
            
        }
    }
}